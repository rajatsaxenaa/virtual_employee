


<div class="container mt-3">
    <div class="row">
        <div class="col-xl-8 p-4 m-auto shadow">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title text-info"> Show Students </h5>
                </div>
                <table class="table table-striped table-bordered mt-4">
        <thead>
            <th> Name </th>
            
            <th> Email </th>
           
          
        </thead>
        <tbody>
                <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              
                
                <td> <?php echo e($student->name); ?> </td>
                <td> <?php echo e($student->email); ?> </td>
                
              
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
</table>

                </div>

                <div class="form-group">
                    <a href=" <?php echo e(route('teacher.index')); ?>" class="btn btn-danger"> Close <i class="fa fa-times-circle"></i></a>
                </div>

                </div>
            </div>
        </div>
    </div>
<?php echo $__env->make('student/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test\resources\views/teacher/show.blade.php ENDPATH**/ ?>