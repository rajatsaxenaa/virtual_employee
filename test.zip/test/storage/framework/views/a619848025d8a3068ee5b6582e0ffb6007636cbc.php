
<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">
            <a href="<?php echo e(url('teacher/create')); ?>" class="btn btn-info float-right"><i class="fas fa-plus-circle"></i> Add New </a>
        </div>
    </div>

    <table class="table table-striped table-bordered mt-4">
        <thead>
            <th> Name </th>
            
            <th> Email </th>
            <th> Action </th>
          
        </thead>

        <tbody>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              
                
                <td> <?php echo e($student->name); ?> </td>
                <td> <?php echo e($student->email); ?> </td>
                
                <td> <a href="<?php echo e(route('teacher.show', $student->id )); ?>" class="badge badge-info"> View Student </a>
                
                    <a href="<?php echo e(route('teacher.edit', $student->id )); ?>" class="badge badge-success"> Edit </a>
                    <form action="<?php echo e(route('teacher.destroy', $student->id)); ?>" method="post">
                     <?php echo csrf_field(); ?>
                     <?php echo method_field('DELETE'); ?>
                        <button class="badge btn-danger" type="submit"> Delete </button>
                   </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php echo $__env->make('./student/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test\resources\views/teacher/index.blade.php ENDPATH**/ ?>