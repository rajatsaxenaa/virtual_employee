<?php

use Illuminate\Database\Seeder;
use App\TeachersData;
use App\StudentssData;
class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(UserSeeder::class);
        $this->call(TeachersDataTableSeeder::class);
        $this->call(StudentsDataTableSeeder::class);
    }
}
