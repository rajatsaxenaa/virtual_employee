<?php

use Illuminate\Database\Seeder;
use App\TeachersData;
class TeachersDataTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $count = 100;
        factory(TeachersData::class, $count)->create();
    }
}
