<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\StudentssData;
use Faker\Generator as Faker;

$factory->define(StudentssData::class, function (Faker $faker) {
    return [
        
        'name' => $faker->name,
        'email' => $faker->email,
       
    ];
});
