<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\TeachersData;
use Faker\Generator as Faker;

$factory->define(TeachersData::class, function (Faker $faker) {
    return [
        'name' => $faker->name,
        'email' => $faker->email,
       
    ];
});
