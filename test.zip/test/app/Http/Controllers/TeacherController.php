<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\TeachersData;

class TeacherController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $students       =       TeachersData::all();

        // passing data into view
        return view('teacher/index', compact('students'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('teacher/create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name'        =>          'required',
            'email'         =>          'required',
           
        ]);
           
            $student = new TeachersData;
    $student->name = $request->name;
    $student->email = $request->email;
    //print_r($student);die();
    
    $student->save();
    return back()->with('success', 'Record created successfully');
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $student = \DB::table('studentss_data')
    ->select('studentss_data.name','studentss_data.email')
    ->join('teachers_data', 'studentss_data.teacher_id', '=', 'teachers_data.id')
    ->where('teachers_data.id', $id)
    ->get();
       // $student    =       TeachersData::find($id);
       //  print_r($student);die;
         return view('teacher/show', compact('student'));
    }

    

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $student    =       TeachersData::find($id);
        return view('teacher/update', compact('student'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $student     =    $request->validate([
            'name'        =>          'required',
            'email'         =>          'required',
           
        ]);
   
   
        TeachersData::where('id', $id)->update($student);
   
        return back()->with('success', 'Record updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $student = TeachersData::findOrFail($id);
        $student->delete();
        return redirect('teacher')->with('success', 'Record deleted successfully');
    }
}
