

@extends('student/layout')
<div class="container mt-3">
    <div class="row">
        <div class="col-xl-8 p-4 m-auto shadow">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title text-info"> Show Students </h5>
                </div>
                <table class="table table-striped table-bordered mt-4">
        <thead>
            <th> Name </th>
            
            <th> Email </th>
           
          
        </thead>
        <tbody>
                @foreach($student as $student)
            <tr>
              
                
                <td> {{ $student->name }} </td>
                <td> {{ $student->email }} </td>
                
              
            </tr>
            @endforeach
            </tbody>
</table>

                </div>

                <div class="form-group">
                    <a href=" {{ route('teacher.index')}}" class="btn btn-danger"> Close <i class="fa fa-times-circle"></i></a>
                </div>

                </div>
            </div>
        </div>
    </div>